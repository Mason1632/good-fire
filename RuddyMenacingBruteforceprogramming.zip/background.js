async function main() {
  await replit.init();

  // await replit.messages.showConfirm('Background script loaded!')
}

main();
